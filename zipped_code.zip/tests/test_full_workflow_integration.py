import json
import pytest
from pathlib import Path

# --- GLOBAL PATCHES ---

@pytest.fixture(autouse=True)
def patch_aisummarizer(monkeypatch):
    """
    Replace AISummarizer with a MagicMock to avoid real external calls.
    """
    from unittest.mock import MagicMock
    mock_ai = MagicMock()
    mock_ai.summarize_entries_bulk.return_value = "This is a mocked summary."
    monkeypatch.setattr("scripts.ai_summarizer.AISummarizer", lambda: mock_ai)

@pytest.fixture(autouse=True)
def patch_load_config(monkeypatch):
    """
    Override load_config to return a static test configuration.
    """
    monkeypatch.setattr("scripts.config_loader.load_config", lambda: {
        "batch_size": 5,
        "logs_dir": "logs",
        "export_dir": "exports",
        "correction_summaries_path": "logs/correction_summaries.json",
        "raw_log_path": "logs/zephyrus_log.json",
        "force_summary_tracker_rebuild": True,
        "test_mode": True,
        # vector_store is the default location for FAISS indexes:
        "raw_log_index_path": "vector_store/raw_index.faiss",
        "raw_log_metadata_path": "vector_store/raw_metadata.pkl",
        "faiss_index_path": "vector_store/summary_index.faiss",
        "faiss_metadata_path": "vector_store/summary_metadata.pkl"
    })

@pytest.fixture(autouse=True)
def patch_get_absolute_path(monkeypatch, temp_dir):
    """
    Override get_absolute_path so that all paths are resolved relative to temp_dir.
    """
    monkeypatch.setattr("scripts.config_loader.get_absolute_path", lambda x: str(temp_dir / x))

# --- TEMP DIRECTORY FIXTURES ---

@pytest.fixture
def temp_dir(tmp_path):
    """
    Create a temporary directory structure at the root of temp_dir
    that matches the config's folder names:
      - logs
      - exports
      - vector_store
    """
    (tmp_path / "logs").mkdir(parents=True, exist_ok=True)
    (tmp_path / "exports").mkdir(parents=True, exist_ok=True)
    (tmp_path / "vector_store").mkdir(parents=True, exist_ok=True)
    return tmp_path

@pytest.fixture
def raw_log_path(temp_dir):
    """
    Provides the path for the raw log file (as referenced by the config: 'logs/zephyrus_log.json').
    """
    return Path(str(temp_dir / "logs/zephyrus_log.json"))

@pytest.fixture
def logger_core(temp_dir):
    """
    Initialize ZephyrusLoggerCore using the temporary directory.
    This ensures that all file operations occur in the test environment.
    """
    from scripts.core import ZephyrusLoggerCore  # Import after patches
    # Force deletion of any existing files in the test directory.
    log_file = Path(str(temp_dir / "logs/zephyrus_log.json"))
    tracker_file = Path(str(temp_dir / "logs/summary_tracker.json"))
    for f in [log_file, tracker_file]:
        if f.exists():
            f.unlink()
        f.write_text("{}", encoding="utf-8")
    return ZephyrusLoggerCore(script_dir=temp_dir)

# --- TESTS ---

def test_full_workflow_multiple_dates(logger_core, monkeypatch):
    """
    End-to-end integration test with entries on different dates:
      1. Clear existing logs and tracker.
      2. Log entries on two different dates without auto-triggering summarization.
      3. Verify that unsummarized entries are aggregated globally.
      4. Trigger global summarization.
      5. Verify that the global summary is stored under the "global" key.
      6. Confirm that unsummarized entries are 0 after summarization.
    """
    main_category = "MultiDateTest"
    subcategory = "GlobalWorkflow"
    date1 = "2025-03-22"
    date2 = "2025-03-23"
    ts1 = date1 + " 10:00:00"
    ts2 = date2 + " 11:00:00"

    # Clear log and summary tracker files and reset in-memory tracker.
    for f in [logger_core.json_log_file, logger_core.summary_tracker_file]:
        if f.exists():
            f.unlink()
        f.write_text("{}", encoding="utf-8")
    logger_core.summary_tracker = {}

    # Disable auto-triggering during logging.
    monkeypatch.setattr(logger_core, "generate_global_summary", lambda mc, sc: False)

    # Log 3 entries on date1.
    for i in range(3):
        logger_core.log_to_json(ts1, date1, main_category, subcategory, f"Entry {i} on {date1}")

    # Log 2 entries on date2.
    for i in range(2):
        logger_core.log_to_json(ts2, date2, main_category, subcategory, f"Entry {i} on {date2}")

    # Verify unsummarized entries count is 5.
    unsummarized = logger_core.get_unsummarized_entries_across_days(main_category, subcategory)
    assert len(unsummarized) >= 5, f"Expected at least 5 unsummarized entries, got {len(unsummarized)}"

    # Remove the patch so that generate_global_summary functions normally.
    monkeypatch.undo()

    # Trigger global summarization manually.
    success = logger_core.generate_global_summary(main_category, subcategory)
    assert success, "Global summarization did not succeed."

    # After summarization, unsummarized entries should be 0.
    unsummarized_after = logger_core.get_unsummarized_entries_across_days(main_category, subcategory)
    assert len(unsummarized_after) == 0, f"Expected 0 unsummarized entries after summarization, got {len(unsummarized_after)}"

    # Verify that correction summaries file contains a global summary.
    summaries = json.loads(logger_core.correction_summaries_file.read_text(encoding="utf-8"))
    assert "global" in summaries, "Global key not found in correction summaries."
    assert main_category in summaries["global"], f"Category '{main_category}' not found under global."
    assert subcategory in summaries["global"][main_category], f"Subcategory '{subcategory}' not found under global."
    batch_summary = summaries["global"][main_category][subcategory][0]
    assert batch_summary["original_summary"] == "This is a mocked summary.", "Unexpected summary text."


def test_faiss_index_build_and_search(logger_core, monkeypatch):
    main_category = "IntegrationTest"
    subcategory = "Workflow"
    forced_date = "2025-03-22"
    timestamp = forced_date + " 12:00:00"

    # Clear log and summary tracker, and reset in-memory tracker.
    for f in [logger_core.json_log_file, logger_core.summary_tracker_file]:
        if f.exists():
            f.unlink()
        f.write_text("{}", encoding="utf-8")
    logger_core.summary_tracker = {}

    # Log 5 entries with the forced date.
    for i in range(5):
        logger_core.log_to_json(timestamp, forced_date, main_category, subcategory, f"Test entry {i}")

    success = logger_core.generate_global_summary(main_category, subcategory)
    assert success, "Global summarization did not succeed."

    # Build a FAISS index from the global summaries.
    from scripts.summary_indexer import SummaryIndexer
    indexer = SummaryIndexer()
    texts, meta = indexer.load_entries()
    assert "This is a mocked summary." in texts, "Expected summary not found in loaded texts."

    build_success = indexer.build_index(texts, meta)
    assert build_success, "Failed to build FAISS index from global summaries."

    results = indexer.search("mocked", top_k=5)
    assert len(results) > 0, "No search results returned for query 'mocked'."


def test_raw_log_index_integration(raw_log_path):
    import json
    # Clear raw log file.
    if raw_log_path.exists():
        raw_log_path.unlink()
    raw_log_path.write_text("{}", encoding="utf-8")
    # Write raw logs with entries on two dates.
    logs = {
        "2025-03-22": {
            "RawCat": {
                "SubRaw": [{"timestamp": "2025-03-22 10:00:00", "content": f"raw entry {i}"} for i in range(3)]
            }
        },
        "2025-03-23": {
            "RawCat": {
                "SubRaw": [{"timestamp": "2025-03-23 11:00:00", "content": f"raw entry {i}"} for i in range(4)]
            }
        }
    }
    raw_log_path.write_text(json.dumps(logs, indent=2), encoding="utf-8")

    from scripts.raw_log_indexer import RawLogIndexer
    indexer = RawLogIndexer()
    texts, meta = indexer.load_entries()
    # Now we expect exactly 7 entries.
    assert len(texts) == 7, f"Expected 7 raw log entries, got {len(texts)}"

    build_success = indexer.build_index(texts, meta)
    assert build_success, "Failed to build FAISS index from raw logs."

    results = indexer.search("raw", top_k=5)
    assert len(results) > 0, "No search results returned for raw log query 'raw'."


def test_fallback_mechanism(logger_core, monkeypatch):
    """
    Verify that if the AI summarization fails, the fallback mechanism is triggered.
    """
    class DummySummarizer:
        def summarize_entries_bulk(self, entries, subcategory=None):
            raise Exception("Simulated failure")
        def _fallback_summary(self, full_prompt):
            return "Fallback summary used."

    logger_core.ai_summarizer = DummySummarizer()

    # Clear log and summary tracker, and reset in-memory tracker.
    forced_date = "2025-03-22"
    timestamp = forced_date + " 12:00:00"
    main_category = "FallbackTest"
    subcategory = "Workflow"
    for f in [logger_core.json_log_file, logger_core.summary_tracker_file]:
        if f.exists():
            f.unlink()
        f.write_text("{}", encoding="utf-8")
    logger_core.summary_tracker = {}

    # Disable auto-triggering during logging.
    monkeypatch.setattr(logger_core, "generate_global_summary", lambda mc, sc: False)

    for i in range(5):
        logger_core.log_to_json(timestamp, forced_date, main_category, subcategory, f"Entry {i}")

    monkeypatch.undo()
    success = logger_core.generate_global_summary(main_category, subcategory)
    assert success, "Fallback summarization did not succeed."

    summaries = json.loads(logger_core.correction_summaries_file.read_text(encoding="utf-8"))
    batch_summary = summaries["global"][main_category][subcategory][0]
    assert batch_summary["original_summary"] == "Fallback summary used."


def test_sequential_workflow(logger_core, monkeypatch):
    """
    Simulate a sequential workflow:
      1. Log an initial batch and trigger global summarization.
      2. Log additional entries.
      3. Trigger a second summarization cycle.
      4. Verify that only the new entries are summarized.
    """
    main_category = "SequentialTest"
    subcategory = "Workflow"
    forced_date = "2025-03-22"
    timestamp = forced_date + " 12:00:00"

    # Clear log and tracker, and reset in-memory tracker.
    for f in [logger_core.json_log_file, logger_core.summary_tracker_file]:
        if f.exists():
            f.unlink()
        f.write_text("{}", encoding="utf-8")
    logger_core.summary_tracker = {}

    # Disable auto-triggering during logging.
    monkeypatch.setattr(logger_core, "generate_global_summary", lambda mc, sc: False)

    # Log 5 initial entries.
    for i in range(5):
        logger_core.log_to_json(timestamp, forced_date, main_category, subcategory, f"Initial entry {i}")

    monkeypatch.undo()
    success1 = logger_core.generate_global_summary(main_category, subcategory)
    assert success1, "Initial global summarization failed."

    # Log 3 additional entries.
    for i in range(3):
        logger_core.log_to_json(timestamp, forced_date, main_category, subcategory, f"New entry {i}")

    unsummarized = logger_core.get_unsummarized_entries_across_days(main_category, subcategory)
    assert len(unsummarized) == 3, f"Expected 3 unsummarized entries, got {len(unsummarized)}"

    success2 = logger_core.generate_global_summary(main_category, subcategory)
    assert success2, "Second global summarization failed."

    unsummarized_after = logger_core.get_unsummarized_entries_across_days(main_category, subcategory)
    assert len(unsummarized_after) == 0, "Expected no unsummarized entries after second summarization."

    summaries = json.loads(logger_core.correction_summaries_file.read_text(encoding="utf-8"))
    global_summaries = summaries.get("global", {}).get(main_category, {}).get(subcategory, [])
    assert len(global_summaries) == 2, "Expected 2 global summary batches."
