import pytest
import json
from pathlib import Path
from unittest.mock import MagicMock


# 🧠 GLOBAL PATCHES BEFORE IMPORTS

@pytest.fixture(autouse=True)
def patch_aisummarizer(monkeypatch):
    """
    Replace the AISummarizer with a MagicMock to avoid actual external calls.
    """
    mock_ai = MagicMock()
    mock_ai.summarize_entries_bulk.return_value = "This is a mocked summary."
    monkeypatch.setattr("scripts.ai_summarizer.AISummarizer", lambda: mock_ai)


@pytest.fixture(autouse=True)
def patch_get_absolute_path(monkeypatch, temp_dir):
    # Force get_absolute_path to resolve paths relative to the temporary directory.
    monkeypatch.setattr("scripts.config_loader.get_absolute_path", lambda x: str(temp_dir / x))


@pytest.fixture(autouse=True)
def patch_load_config(monkeypatch):
    """
    Override load_config to return a static test config.
    """
    monkeypatch.setattr("scripts.config_loader.load_config", lambda: {
        "batch_size": 5,
        "logs_dir": "tests/mock_data/logs",
        "export_dir": "tests/mock_data/exports",
        "correction_summaries_path": "tests/mock_data/logs/correction_summaries.json",
        "raw_log_path": "tests/mock_data/logs/zephyrus_log.json",
        "test_mode": True,
        "force_summary_tracker_rebuild": True
    })


# 🧪 TEMP DIRECTORY STRUCTURE

@pytest.fixture
def temp_dir(tmp_path):
    """
    Create a temporary directory structure for logs, vector store, and exports.
    """
    (tmp_path / "tests/mock_data/logs").mkdir(parents=True)
    (tmp_path / "tests/mock_data/vector_store").mkdir(parents=True)
    (tmp_path / "tests/mock_data/exports").mkdir(parents=True)
    return tmp_path


@pytest.fixture
def logger_core(temp_dir):
    """
    Initialize ZephyrusLoggerCore using the temporary directory.
    """
    from scripts.core import ZephyrusLoggerCore  # Import after patches
    return ZephyrusLoggerCore(script_dir=temp_dir)


# 🧪 TESTS START HERE

def test_initialization_creates_files(logger_core):
    """
    Ensure that on initialization, all required files are created.
    """
    assert logger_core.json_log_file.exists()
    assert logger_core.txt_log_file.exists()
    assert logger_core.correction_summaries_file.exists()
    assert logger_core.summary_tracker_file.exists()


def test_log_to_json_creates_structure(logger_core):
    """
    Verify that log_to_json correctly creates a nested log structure.
    (Entries are still stored date‑wise even though summaries are global.)
    """
    timestamp = "2025-03-22 12:00:00"
    date_str = "2025-03-22"
    main_category = "TestCategory"
    subcategory = "SubTest"
    entry = "This is a test entry."

    success = logger_core.log_to_json(timestamp, date_str, main_category, subcategory, entry)
    assert success

    logs = json.loads(logger_core.json_log_file.read_text(encoding="utf-8"))
    assert date_str in logs
    assert main_category in logs[date_str]
    assert subcategory in logs[date_str][main_category]
    assert logs[date_str][main_category][subcategory][0]["content"] == entry


def test_generate_global_summary_triggers_and_writes_summary(logger_core, monkeypatch):
    """
    Verify that generate_global_summary creates a summary and stores it under the "global" key.
    """
    main_category = "TestCat"
    subcategory = "SubCat"
    date_str = "2025-03-22"
    # Create a log with exactly 5 entries.
    logs = {
        date_str: {
            main_category: {
                subcategory: [
                    {"timestamp": f"{date_str} 12:00:0{i}", "content": f"entry {i}"} for i in range(5)
                ]
            }
        }
    }
    logger_core.json_log_file.write_text(json.dumps(logs, indent=2), encoding="utf-8")

    # Force unsummarized entries to be the 5 entries.
    monkeypatch.setattr(logger_core, "get_unsummarized_entries_across_days",
                        lambda mc, sc: [f"entry {i}" for i in range(5)])
    success = logger_core.generate_global_summary(main_category, subcategory)
    assert success

    summaries = json.loads(logger_core.correction_summaries_file.read_text(encoding="utf-8"))
    # Global summaries must be stored under the "global" key.
    assert "global" in summaries
    assert main_category in summaries["global"]
    assert subcategory in summaries["global"][main_category]
    batch_summary = summaries["global"][main_category][subcategory][0]
    assert batch_summary["original_summary"] == "This is a mocked summary."


def test_generate_summary_fallback(logger_core, monkeypatch):
    """
    Verify that if summarization fails, the fallback is used and a global summary is written.
    """

    class DummySummarizer:
        def summarize_entries_bulk(self, entries, subcategory=None):
            raise Exception("Ollama down")

        def _fallback_summary(self, full_prompt):
            return "This is a mocked summary."

    logger_core.ai_summarizer = DummySummarizer()
    logs = {
        "2025-03-22": {
            "TestCat": {
                "SubCat": [{"timestamp": "2025-03-22 12:00:00", "content": f"entry {i}"} for i in range(5)]
            }
        }
    }
    logger_core.json_log_file.write_text(json.dumps(logs, indent=2), encoding="utf-8")
    monkeypatch.setattr(logger_core, "get_unsummarized_entries_across_days",
                        lambda mc, sc: [f"entry {i}" for i in range(5)])
    success = logger_core.generate_global_summary("TestCat", "SubCat")
    assert success

    summaries = json.loads(logger_core.correction_summaries_file.read_text(encoding="utf-8"))
    batch_summary = summaries["global"]["TestCat"]["SubCat"][0]
    assert batch_summary["original_summary"] == "This is a mocked summary."


def test_generate_global_summary_across_days(logger_core, monkeypatch):
    """
    Test that generate_global_summary aggregates unsummarized entries across dates and writes under "global".
    """
    day_1 = "2025-03-22"
    day_2 = "2025-03-23"
    main_category = "CrossDayCat"
    subcategory = "SubCross"

    logs = {
        day_1: {main_category: {
            subcategory: [{"timestamp": f"{day_1} 10:00:00", "content": f"entry {i}"} for i in range(3)]}},
        day_2: {main_category: {
            subcategory: [{"timestamp": f"{day_2} 11:00:00", "content": f"entry {i}"} for i in range(5)]}},
    }
    logger_core.json_log_file.write_text(json.dumps(logs, indent=2), encoding="utf-8")
    # Patch get_unsummarized_entries_across_days to return 8 entries.
    monkeypatch.setattr(logger_core, "get_unsummarized_entries_across_days",
                        lambda mc, sc: [f"entry {i}" for i in range(8)])
    success = logger_core.generate_global_summary(main_category, subcategory)
    assert success

    summaries = json.loads(logger_core.correction_summaries_file.read_text(encoding="utf-8"))
    assert "global" in summaries
    assert main_category in summaries["global"]
    assert subcategory in summaries["global"][main_category]
    batch_summary = summaries["global"][main_category][subcategory][0]
    assert batch_summary["original_summary"] == "This is a mocked summary."
