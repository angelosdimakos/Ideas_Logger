import pytest
from pathlib import Path
from unittest.mock import MagicMock

# --- GLOBAL FIXTURES/PATCHES ---
@pytest.fixture(autouse=True, scope="session")
def patch_aisummarizer(monkeypatch):
    """
    Replace AISummarizer with a MagicMock to avoid real external calls.
    """
    mock_ai = MagicMock()
    mock_ai.summarize_entries_bulk.return_value = "This is a mocked summary."
    monkeypatch.setattr("scripts.ai_summarizer.AISummarizer", lambda: mock_ai)

@pytest.fixture(autouse=True, scope="session")
def patch_load_config(monkeypatch):
    """
    Override load_config to return a static test configuration.
    """
    monkeypatch.setattr("scripts.config_loader.load_config", lambda: {
        "batch_size": 5,
        "logs_dir": "logs",
        "export_dir": "exports",
        "correction_summaries_path": "logs/correction_summaries.json",
        "raw_log_path": "logs/zephyrus_log.json",
        "raw_log_index_path": "vector_store/raw_index.faiss",
        "raw_log_metadata_path": "vector_store/raw_metadata.pkl",
        "faiss_index_path": "vector_store/summary_index.faiss",
        "faiss_metadata_path": "vector_store/summary_metadata.pkl",
        "force_summary_tracker_rebuild": True,
        "test_mode": True,
        "embedding_model": "all-MiniLM-L6-v2"
    })

@pytest.fixture(autouse=True, scope="session")
def patch_get_absolute_path(monkeypatch, temp_dir):
    """
    Override get_absolute_path so that all paths are resolved relative to temp_dir.
    """
    monkeypatch.setattr("scripts.config_loader.get_absolute_path", lambda x: str(temp_dir / x))

# --- TEMP DIRECTORY FIXTURES ---
@pytest.fixture(scope="session")
def temp_dir(tmp_path_factory):
    """
    Create a temporary directory structure for logs, exports, and vector_store.
    """
    base = tmp_path_factory.mktemp("temp_test_env")
    (base / "logs").mkdir(parents=True, exist_ok=True)
    (base / "exports").mkdir(parents=True, exist_ok=True)
    (base / "vector_store").mkdir(parents=True, exist_ok=True)
    return base

@pytest.fixture
def raw_log_path(temp_dir):
    """
    Provides the path for the raw log file.
    """
    return Path(str(temp_dir / "logs/zephyrus_log.json"))

@pytest.fixture
def logger_core(temp_dir):
    """
    Initialize ZephyrusLoggerCore using the temporary directory.
    """
    from scripts.core import ZephyrusLoggerCore  # Import after patches
    # Ensure that the necessary files are cleared.
    for file_rel in ["logs/zephyrus_log.json", "logs/summary_tracker.json"]:
        p = temp_dir / file_rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("{}", encoding="utf-8")
    return ZephyrusLoggerCore(script_dir=temp_dir)
